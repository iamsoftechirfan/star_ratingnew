<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(config('app.google_maps_api_key')); ?>&callback=initMap" async defer></script>

    <link href="css/style.css" rel="stylesheet">
    <style>
        /* Style for the map container */
        #header{
            width: auto;
            padding-top: 10px;
            padding-bottom: 20px;
            padding-left: 10%;
        }
        #map-container {
            height: 400px;
            width: 100%;
            position: relative;
        }

        /* Style for the card */
        #map-card {
            width: 500px;
            height: 580px;
            margin: 10px;
            line-height: 1cm;
            background-color: #043265;
            color: #fff;
            position: absolute;
            top: 40%;
            left: 10%;
            z-index: 1;
            padding: 10px;
            border-radius: 10px;
            border: 2px solid #000000;
            
        }

        li {
            font-size: 18px;
            margin: 10px 0;
        }

        input[type="text"] {
            width: 100%;
            border-radius: 5px;
            height: 40px;
        }
        .floating-buttons {
            position: fixed;
            bottom: 20px;
            right: 20px;
        }
        .floating-buttons button {
            display: block;
            margin: 10px 0;
            background-color: darkblue;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
        }

    </style>
</head>

<body>
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Navbar</a>
        </div>
    </nav>
    <div id="header">
        <h1>Sternerechner Tool</h1>
        <h2>Online Löschpotenzial berechnen</h2>
        <br>
        <h3>Vergleichen Sie Ihre Mitbewerber und exportieren Sie Ihre Bewertungen als PDF.</h3>
    </div>
    <!-- The card to display information -->
    <div id="map-card">
        <h1>Scannen, Löschen,<br>Monitoring, Bewertungsfilter</h1>
        <ul>
            <li>Prüfen Sie Ihr Löschpotenzial in 10 Sekunden</li>
            <li>Wettbewerber vergleichen</li>
            <li>Kostenloses Monitoring Ihrer Bewertungen</li>
            <li>Bewertungsfilter für negative Bewertungen einrichten</li>
        </ul>
        <p>Bitte geben Sie den genauen Namen Ihres Google My Business Profils ein. Wir analysieren Ihre Bewertungen und kontaktieren Sie.</p>
        <form action="/action_page.php">
            <input id="autocomplete" type="text" placeholder="Search for a location">
        </form>
        <button type="submit" style="background-color: darkblue;color: #fff;border: none;border-radius: 5px;padding: 10px 20px;font-size: 18px;cursor: pointer;margin-top: 10px;">Calculate</button>
    </div>

    <!-- The map container -->
    <div id="map-container" class="mb-5"></div>
    <div class="floating-buttons">
        <button>Mail</button>
        <button>Call</button>
        <button>Whatsapp</button>
    </div>

    
    <script>
        function initMap() {
            const map = new google.maps.Map(document.getElementById('map-container'), {
                center: { lat: 20.5937, lng: 78.9629 }, 
                zoom: 12,
            });
            var searchInput='autocomplete';
            $(document).ready(function(){
               var auto;
               auto = new google.maps.places.Autocomplete((document.getElementById(autocomplete)),{
                types: ['geocode'],
               }); 
            });
        }

        initMap();

    </script>

    <!-- Load the Google Maps JavaScript API with your API key -->
    <!-- <script src="https://AIzaSyDc8IfB5vM1DQxq_jLd-hIauX7PwyszXOU" async defer></script> -->
    
</body>

</html><?php /**PATH C:\xampp\htdocs\star_ratings\resources\views/rating-calculator.blade.php ENDPATH**/ ?>