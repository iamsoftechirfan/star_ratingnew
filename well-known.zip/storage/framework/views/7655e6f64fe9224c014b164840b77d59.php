<p>Hello, <?php echo e($name); ?>!</p>
<p><?php echo e($description); ?>.</p><?php /**PATH E:\xampppp\htdocs\star_ratings\resources\views/emails/my_custom_template.blade.php ENDPATH**/ ?>